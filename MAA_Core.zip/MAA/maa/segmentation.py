"""Foreground segmentation with a frozen, off-the-shelf Mask R-CNN.

The segmenter is a general-purpose pretrained model used only to obtain
foreground masks; it is never a victim and is kept fully frozen.
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from torchvision.models.detection import maskrcnn_resnet50_fpn, MaskRCNN_ResNet50_FPN_Weights


class MaskRCNNSegmenter(nn.Module):
    def __init__(self, device):
        super().__init__()
        weights = MaskRCNN_ResNet50_FPN_Weights.DEFAULT
        self.model = maskrcnn_resnet50_fpn(weights=weights).to(device).eval()
        for p in self.model.parameters():
            p.requires_grad_(False)

    @torch.no_grad()
    def forward(self, img_bchw, score_thr=0.7, max_instances=3, fallback="all"):
        device = img_bchw.device
        B, _, H, W = img_bchw.shape
        out_masks = []
        for b in range(B):
            x = img_bchw[b]
            preds = self.model([x])[0]

            if ("masks" not in preds) or preds["masks"].numel() == 0:
                out_masks.append(torch.ones((H, W), device=device) if fallback == "all"
                                 else torch.zeros((H, W), device=device))
                continue

            scores = preds["scores"]
            keep = scores >= score_thr
            if keep.sum().item() == 0:
                out_masks.append(torch.ones((H, W), device=device) if fallback == "all"
                                 else torch.zeros((H, W), device=device))
                continue

            idxs = torch.nonzero(keep).squeeze(1)
            idxs = idxs[torch.argsort(scores[idxs], descending=True)]
            idxs = idxs[:max_instances]

            masks = preds["masks"][idxs, 0]  # (M,H,W) prob
            union_prob = masks.max(dim=0).values  # soft union
            out_masks.append(union_prob)

        return torch.stack(out_masks, dim=0)


def mask_to_bbox(mask_hw, thr=0.3, pad=8):
    H, W = mask_hw.shape
    ys, xs = torch.where(mask_hw > thr)
    if ys.numel() == 0:
        return (0, H, 0, W)
    y0 = int(max(0, ys.min().item() - pad))
    y1 = int(min(H, ys.max().item() + 1 + pad))
    x0 = int(max(0, xs.min().item() - pad))
    x1 = int(min(W, xs.max().item() + 1 + pad))
    return (y0, y1, x0, x1)


def crop_resize_2d_batch(x_bhw, bboxes, out_hw=(128, 128)):
    B, H, W = x_bhw.shape
    out = []
    for b in range(B):
        y0, y1, x0, x1 = bboxes[b]
        crop = x_bhw[b:b+1, y0:y1, x0:x1]  # (1,h,w)
        crop = crop.unsqueeze(1)           # (1,1,h,w)
        crop = F.interpolate(crop, size=out_hw, mode="bilinear", align_corners=False)
        out.append(crop.squeeze(1))        # (1,outH,outW)
    return torch.cat(out, dim=0)
