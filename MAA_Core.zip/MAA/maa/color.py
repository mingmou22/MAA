"""HSV color-space utilities (differentiable, pure PyTorch)."""

import math
import torch


def rgb_to_hsv(img):
    r, g, b = img[:, 0], img[:, 1], img[:, 2]
    maxc, _ = torch.max(img, dim=1)
    minc, _ = torch.min(img, dim=1)
    v = maxc

    deltac = maxc - minc + 1e-6
    s = deltac / (maxc + 1e-6)

    rc = (maxc - r) / deltac
    gc = (maxc - g) / deltac
    bc = (maxc - b) / deltac

    h = torch.zeros_like(maxc)
    h[r == maxc] = (bc - gc)[r == maxc]
    h[g == maxc] = 2.0 + (rc - bc)[g == maxc]
    h[b == maxc] = 4.0 + (gc - rc)[b == maxc]
    h = (h / 6.0) % 1.0
    return h, s, v


def hsv_to_rgb(h, s, v):
    i = torch.floor(h * 6.0)
    f = h * 6.0 - i
    i = i.long() % 6

    p = v * (1 - s)
    q = v * (1 - f * s)
    t = v * (1 - (1 - f) * s)

    out = torch.zeros(h.size(0), 3, h.size(1), h.size(2), device=h.device)

    idx = (i == 0)
    out[:, 0] = torch.where(idx, v, out[:, 0])
    out[:, 1] = torch.where(idx, t, out[:, 1])
    out[:, 2] = torch.where(idx, p, out[:, 2])

    idx = (i == 1)
    out[:, 0] = torch.where(idx, q, out[:, 0])
    out[:, 1] = torch.where(idx, v, out[:, 1])
    out[:, 2] = torch.where(idx, p, out[:, 2])

    idx = (i == 2)
    out[:, 0] = torch.where(idx, p, out[:, 0])
    out[:, 1] = torch.where(idx, v, out[:, 1])
    out[:, 2] = torch.where(idx, t, out[:, 2])

    idx = (i == 3)
    out[:, 0] = torch.where(idx, p, out[:, 0])
    out[:, 1] = torch.where(idx, q, out[:, 1])
    out[:, 2] = torch.where(idx, v, out[:, 2])

    idx = (i == 4)
    out[:, 0] = torch.where(idx, t, out[:, 0])
    out[:, 1] = torch.where(idx, p, out[:, 1])
    out[:, 2] = torch.where(idx, v, out[:, 2])

    idx = (i == 5)
    out[:, 0] = torch.where(idx, v, out[:, 0])
    out[:, 1] = torch.where(idx, p, out[:, 1])
    out[:, 2] = torch.where(idx, q, out[:, 2])

    return out


def hue_embed(h):
    ang = 2 * math.pi * h
    return torch.cos(ang), torch.sin(ang)
