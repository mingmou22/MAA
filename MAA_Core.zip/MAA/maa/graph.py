"""Spatial patch-graph construction and node centrality analysis."""

from collections import deque

import numpy as np
import torch


def build_grid_adjacency(nH: int, nW: int, device=None, eight_connected: bool = True) -> torch.Tensor:
    """8-connected (default) undirected grid adjacency with self-loops, size (nH*nW, nH*nW)."""
    N = nH * nW
    adj = torch.zeros(N, N, device=device)
    nbrs = [(-1, 0), (1, 0), (0, -1), (0, 1)]
    if eight_connected:
        nbrs += [(-1, -1), (-1, 1), (1, -1), (1, 1)]

    def idx(i, j):
        return i * nW + j

    for i in range(nH):
        for j in range(nW):
            u = idx(i, j)
            for di, dj in nbrs:
                ni, nj = i + di, j + dj
                if 0 <= ni < nH and 0 <= nj < nW:
                    adj[u, idx(ni, nj)] = 1.0
    adj = adj + torch.eye(N, device=device)
    return adj


def betweenness_centrality_unweighted(adj: torch.Tensor) -> torch.Tensor:
    A = (adj.detach().cpu() > 0).numpy()
    N = A.shape[0]
    neighbors = []
    for i in range(N):
        nbrs = np.where(A[i])[0].tolist()
        nbrs = [j for j in nbrs if j != i]
        neighbors.append(nbrs)

    bc = np.zeros(N, dtype=np.float64)

    for s in range(N):
        stack = []
        P = [[] for _ in range(N)]
        sigma = np.zeros(N, dtype=np.float64)
        sigma[s] = 1.0
        dist = -np.ones(N, dtype=np.int32)
        dist[s] = 0

        q = deque([s])
        while q:
            v = q.popleft()
            stack.append(v)
            for w in neighbors[v]:
                if dist[w] < 0:
                    q.append(w)
                    dist[w] = dist[v] + 1
                if dist[w] == dist[v] + 1:
                    sigma[w] += sigma[v]
                    P[w].append(v)

        delta = np.zeros(N, dtype=np.float64)
        while stack:
            w = stack.pop()
            for v in P[w]:
                if sigma[w] > 0:
                    delta[v] += (sigma[v] / sigma[w]) * (1.0 + delta[w])
            if w != s:
                bc[w] += delta[w]

    bc *= 0.5
    if N > 2:
        bc *= (2.0 / ((N - 1) * (N - 2)))

    return torch.tensor(bc, dtype=torch.float32)


def centrality_weights(adj: torch.Tensor) -> torch.Tensor:
    bc = betweenness_centrality_unweighted(adj).to(adj.device)
    w = (bc - bc.min()) / (bc.max() - bc.min() + 1e-8)
    return w.unsqueeze(1)
