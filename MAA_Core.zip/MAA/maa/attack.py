"""MAA main attack: structure-guided, per-instance co-optimized perturbation.

Pipeline (per sample, no victim queries, no surrogate):
    1. HSV decomposition of source & target images, foreground masks;
    2. patch graph + betweenness-centrality weights;
    3. Chebyshev spectral diffusion template (theta optimized per instance);
    4. channel-wise alignment losses (fractal / style / frequency);
    5. co-optimization: PGD update of the perturbation + Adam update of theta
       via a one-step lookahead on the alignment losses.
"""

import torch
import torch.nn.functional as F

from .color import rgb_to_hsv, hsv_to_rgb, hue_embed
from .segmentation import MaskRCNNSegmenter, mask_to_bbox, crop_resize_2d_batch
from .graph import centrality_weights
from .diffusion import ChebDiffusion
from .operators import FractalHOperator, VGGStyle
from .patches import graph_smooth_field, qnodes_to_qmap


def structured_hsv_target_attack(
    src_img, tar_img,
    adj,
    segmenter: MaskRCNNSegmenter,
    block_hw=(16, 16),
    stride=None,
    steps=15,               # paper Table I: 15 iterations
    eps=8/255,
    alpha=None,
    lam=3.0,
    lam_hf=0.1,
    score_thr=0.7,
    max_instances=3,
    crop_hw=(128, 128),
    cheb_K=2,               # paper Table I: K = 2
    embed_dim=16,
    q_floor=0.2,
    use_graph_smooth=True,
    learn_theta=True,       # per-instance co-optimization of theta
    theta_lr=1e-2,          # Adam lr for theta
):
    device = src_img.device
    B, _, H, W = src_img.shape
    bh, bw = block_hw
    assert bh == bw, "this implementation assumes square patch"
    patch = bh
    if stride is None:
        stride = patch

    nH = (H - patch) // stride + 1
    nW = (W - patch) // stride + 1
    N = nH * nW
    assert adj.shape == (N, N), f"adj shape {adj.shape} but expected {(N,N)} (check patch/stride)"

    if alpha is None:
        alpha = float(eps) / float(steps)

    FH = FractalHOperator().to(device)
    vgg = VGGStyle().to(device)

    # ===== A: masks on BOTH source & target =====
    with torch.no_grad():
        mask_src = segmenter(src_img, score_thr=score_thr, max_instances=max_instances, fallback="all")
        mask_tar = segmenter(tar_img, score_thr=score_thr, max_instances=max_instances, fallback="all")

    bboxes_src = [mask_to_bbox(mask_src[b], thr=0.3, pad=8) for b in range(B)]
    bboxes_tar = [mask_to_bbox(mask_tar[b], thr=0.3, pad=8) for b in range(B)]

    # ===== B: centrality weights =====
    w = centrality_weights(adj).to(device)  # (N,1)

    # ===== C: learnable spectral diffuser (theta optimized per instance) =====
    diffuser = ChebDiffusion(K=cheb_K, learnable=learn_theta).to(device)
    z = torch.randn(N, embed_dim, device=device)
    H0 = w * z

    theta_opt = None
    if learn_theta:
        theta_opt = torch.optim.Adam([diffuser.theta], lr=theta_lr)

    def high_freq_mask(hh, ww, ratio=0.5):
        yy, xx = torch.meshgrid(
            torch.linspace(-1, 1, hh, device=device),
            torch.linspace(-1, 1, ww, device=device),
            indexing='ij'
        )
        rr = torch.sqrt(xx**2 + yy**2)
        return (rr > ratio).float()

    Mh = high_freq_mask(crop_hw[0], crop_hw[1], ratio=0.5)

    # ---- target-side constants (independent of adv / theta) ----
    with torch.no_grad():
        Ht, St, Vt = rgb_to_hsv(tar_img)
        Ht_c = crop_resize_2d_batch(Ht, bboxes_tar, crop_hw)
        St_c = crop_resize_2d_batch(St, bboxes_tar, crop_hw)
        Vt_c = crop_resize_2d_batch(Vt, bboxes_tar, crop_hw)
        mt_c = crop_resize_2d_batch(mask_tar, bboxes_tar, crop_hw).clamp(0, 1)
        bHc, bHs = FH(hue_embed(Ht_c)[0]), FH(hue_embed(Ht_c)[1])
        Ft = vgg((St_c * mt_c).unsqueeze(1).repeat(1, 3, 1, 1))
        gram_t = VGGStyle.gram(Ft)
        Vf_t = torch.fft.fft2(Vt_c * mt_c)
        abs_Vf_t = torch.abs(Vf_t)

    def channel_losses(adv_in):
        """Return (loss_H, loss_S, loss_V, (Hs, Ss, Vs)); differentiable in adv_in."""
        Hs, Ss, Vs = rgb_to_hsv(adv_in)
        Hs_c = crop_resize_2d_batch(Hs, bboxes_src, crop_hw)
        Ss_c = crop_resize_2d_batch(Ss, bboxes_src, crop_hw)
        Vs_c = crop_resize_2d_batch(Vs, bboxes_src, crop_hw)
        ms_c = crop_resize_2d_batch(mask_src, bboxes_src, crop_hw).clamp(0, 1)

        m_u = (ms_c + mt_c).clamp(0, 1)
        m_int = (ms_c * mt_c).clamp(0, 1)
        m_align = m_int if (m_int.sum() >= 10).item() else m_u

        # ---- H circular alignment ----
        Hs_cos, Hs_sin = hue_embed(Hs_c)
        aHc, aHs = FH(Hs_cos), FH(Hs_sin)
        loss_H = (
            (((aHc - bHc) * m_align) ** 2).sum() +
            (((aHs - bHs) * m_align) ** 2).sum()
        ) / (m_align.sum() + 1e-8)

        # ---- S style alignment ----
        Fs = vgg((Ss_c * m_u).unsqueeze(1).repeat(1, 3, 1, 1))
        loss_S = F.mse_loss(VGGStyle.gram(Fs), gram_t)

        # ---- V frequency alignment + HF suppression ----
        Vf_s = torch.fft.fft2(Vs_c * m_u)
        loss_freq = F.mse_loss(torch.abs(Vf_s), abs_Vf_t)
        loss_hf = (Mh * torch.abs(Vf_s)).pow(2).mean()
        loss_V = loss_freq + lam_hf * loss_hf

        return loss_H, loss_S, loss_V, (Hs, Ss, Vs)

    def build_Q_map():
        """Template from current theta; differentiable w.r.t. diffuser.theta."""
        Q = diffuser(H0, adj)                       # (N,F)
        Qn = Q.norm(dim=1, keepdim=True)            # (N,1)
        Qn = Qn / (Qn.max() + 1e-8)                 # scale-only norm keeps grad stable
        qmap = qnodes_to_qmap(Qn, H, W, patch=patch, stride=stride, B=B)
        return (q_floor + (1.0 - q_floor) * qmap).clamp(0, 1)

    adv = src_img.clone().detach()

    for _ in range(steps):
        adv.requires_grad_(True)

        loss_H, loss_S, loss_V, (Hs, Ss, Vs) = channel_losses(adv)

        gH = torch.autograd.grad(loss_H, Hs, retain_graph=True)[0]
        gS = torch.autograd.grad(loss_S, Ss, retain_graph=True)[0]
        gV = torch.autograd.grad(loss_V, Vs)[0]

        # normalize grads
        gH = gH / (gH.abs().mean(dim=(1, 2), keepdim=True) + 1e-8)
        gS = gS / (gS.abs().mean(dim=(1, 2), keepdim=True) + 1e-8)
        gV = gV / (gV.abs().mean(dim=(1, 2), keepdim=True) + 1e-8)

        M = mask_src

        if learn_theta:
            # ===== theta update: one-step lookahead, first-order only =====
            # treat current grads as constants; theta acts through smoothing + template
            gH_c, gS_c, gV_c = gH.detach(), gS.detach(), gV.detach()
            if use_graph_smooth:
                gH_c = graph_smooth_field(gH_c, adj, diffuser, patch=patch, stride=stride)
                gS_c = graph_smooth_field(gS_c, adj, diffuser, patch=patch, stride=stride)
                gV_c = graph_smooth_field(gV_c, adj, diffuser, patch=patch, stride=stride)
                gH_c = gH_c / (gH_c.abs().mean(dim=(1, 2), keepdim=True) + 1e-8)
                gS_c = gS_c / (gS_c.abs().mean(dim=(1, 2), keepdim=True) + 1e-8)
                gV_c = gV_c / (gV_c.abs().mean(dim=(1, 2), keepdim=True) + 1e-8)

            Q_map = build_Q_map()
            dH = (Q_map * M) * torch.tanh(lam * gH_c)
            dS = (Q_map * M) * torch.tanh(lam * gS_c)
            dV = (Q_map * M) * torch.tanh(lam * gV_c)

            H_new = (Hs.detach() + alpha * dH).clamp(0, 1)
            S_new = (Ss.detach() + alpha * dS).clamp(0, 1)
            V_new = (Vs.detach() + alpha * dV).clamp(0, 1)
            adv_look = hsv_to_rgb(H_new, S_new, V_new)   # differentiable w.r.t. theta

            lH_l, lS_l, lV_l, _ = channel_losses(adv_look)
            look_loss = lH_l + lS_l + lV_l

            theta_opt.zero_grad()
            look_loss.backward()
            theta_opt.step()

        # ===== perturbation (delta) update with current (updated) theta =====
        with torch.no_grad():
            if use_graph_smooth:
                gH_s = graph_smooth_field(gH, adj, diffuser, patch=patch, stride=stride)
                gS_s = graph_smooth_field(gS, adj, diffuser, patch=patch, stride=stride)
                gV_s = graph_smooth_field(gV, adj, diffuser, patch=patch, stride=stride)
                gH_s = gH_s / (gH_s.abs().mean(dim=(1, 2), keepdim=True) + 1e-8)
                gS_s = gS_s / (gS_s.abs().mean(dim=(1, 2), keepdim=True) + 1e-8)
                gV_s = gV_s / (gV_s.abs().mean(dim=(1, 2), keepdim=True) + 1e-8)
            else:
                gH_s, gS_s, gV_s = gH, gS, gV

            Q_map = build_Q_map().detach()
            dH = (Q_map * M) * torch.tanh(lam * gH_s)
            dS = (Q_map * M) * torch.tanh(lam * gS_s)
            dV = (Q_map * M) * torch.tanh(lam * gV_s)

            H_adv = (Hs + alpha * dH).clamp(0, 1)
            S_adv = (Ss + alpha * dS).clamp(0, 1)
            V_adv = (Vs + alpha * dV).clamp(0, 1)

            adv_hsv_rgb = hsv_to_rgb(H_adv, S_adv, V_adv)

            # PGD projection in RGB
            delta = torch.clamp(adv_hsv_rgb - src_img, min=-eps, max=eps)
            adv = torch.clamp(src_img + delta, 0, 1).detach()

    with torch.no_grad():
        Q_map = build_Q_map().detach()
    perturbation = (adv - src_img).detach()
    theta_learned = diffuser.theta.detach().cpu()
    return adv, perturbation, (mask_src, mask_tar), Q_map, theta_learned
