"""Chebyshev spectral graph diffusion with per-instance learnable weights."""

import torch
import torch.nn as nn


class ChebDiffusion(nn.Module):
    """
    K-order Chebyshev spectral graph filter.
    theta is a *learnable* per-order weight vector (nn.Parameter):
    initialized to 1/(k+1) and optimized per instance, jointly with
    the perturbation, by backpropagating the channel alignment losses
    through a one-step lookahead (see structured_hsv_target_attack).
    """
    def __init__(self, K=2, learnable=True):
        super().__init__()
        self.K = K
        init = torch.tensor([1.0 / (k + 1) for k in range(K + 1)], dtype=torch.float32)
        if learnable:
            self.theta = nn.Parameter(init)          # learnable, per-instance
        else:
            self.register_buffer("theta", init)      # fixed baseline variant

    def scaled_laplacian(self, adj):
        N = adj.size(0)
        I = torch.eye(N, device=adj.device)
        deg = adj.sum(1)
        D_inv_sqrt = torch.diag(torch.pow(deg + 1e-8, -0.5))
        L = I - D_inv_sqrt @ adj @ D_inv_sqrt
        L_tilde = L - I
        return L_tilde

    def cheb_polys(self, L_tilde):
        N = L_tilde.size(0)
        T0 = torch.eye(N, device=L_tilde.device)
        if self.K == 0:
            return [T0]
        T1 = L_tilde
        Ts = [T0, T1]
        for _ in range(2, self.K + 1):
            Ts.append(2 * L_tilde @ Ts[-1] - Ts[-2])
        return Ts

    def forward(self, H0, adj):
        L_tilde = self.scaled_laplacian(adj)
        Ts = self.cheb_polys(L_tilde)
        out = 0
        for k, Tk in enumerate(Ts):
            out = out + self.theta[k] * (Tk @ H0)
        return out
