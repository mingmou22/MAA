"""Sliding-window patch <-> node conversions and graph smoothing helpers."""

import torch
import torch.nn.functional as F  # noqa: F401  (used by downstream modules)


def img_to_nodes_bchw(x_bchw, patch, stride):
    """
    x_bchw: (B,1,H,W)
    return nodes: (B,N,1), (nH,nW)
    """
    B, C, H, W = x_bchw.shape
    assert C == 1
    unfold = torch.nn.Unfold(kernel_size=patch, stride=stride)
    patches = unfold(x_bchw)  # (B, patch*patch, N)

    nodes = patches.mean(dim=1, keepdim=True)  # (B,1,N)
    nodes = nodes.transpose(1, 2)              # (B,N,1)

    nH = (H - patch) // stride + 1
    nW = (W - patch) // stride + 1
    return nodes, (nH, nW)


def nodes_to_img_bchw(nodes_bn1, H, W, patch, stride):
    """
    nodes_bn1: (B,N,1)
    return: (B,1,H,W) via overlap-add average
    """
    B, N, _ = nodes_bn1.shape
    fold = torch.nn.Fold(output_size=(H, W), kernel_size=patch, stride=stride)

    vals = nodes_bn1.transpose(1, 2)          # (B,1,N)
    vals = vals.repeat(1, patch * patch, 1)   # (B,patch*patch,N)
    out = fold(vals)                          # (B,1,H,W)

    # overlap count normalization
    ones = torch.ones((B, 1, H, W), device=nodes_bn1.device, dtype=nodes_bn1.dtype)
    unfold = torch.nn.Unfold(kernel_size=patch, stride=stride)
    denom = fold(unfold(ones))                # (B,1,H,W)
    out = out / (denom + 1e-8)
    return out


def graph_smooth_field(field_bhw, adj, diffuser, patch, stride):
    
    
    B, H, W = field_bhw.shape
    nodes, _ = img_to_nodes_bchw(field_bhw.unsqueeze(1), patch=patch, stride=stride)  # (B,N,1)

    ys = []
    for b in range(B):
        ys.append(diffuser(nodes[b], adj))  # (N,1)
    y = torch.stack(ys, dim=0)  # (B,N,1)

    smoothed = nodes_to_img_bchw(y, H, W, patch=patch, stride=stride).squeeze(1)  # (B,H,W)
    return smoothed


def qnodes_to_qmap(Q_nodes_n1, H, W, patch, stride, B):
    """
    Q_nodes_n1: (N,1) -> (B,H,W) continuous map via fold averaging
    """
    q = Q_nodes_n1.unsqueeze(0).repeat(B, 1, 1)  # (B,N,1)
    qmap = nodes_to_img_bchw(q, H, W, patch=patch, stride=stride).squeeze(1)  # (B,H,W)
    return qmap
