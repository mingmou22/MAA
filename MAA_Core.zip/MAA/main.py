import argparse
import random

import numpy as np
import torch
from PIL import Image

from maa import (
    MaskRCNNSegmenter,
    build_grid_adjacency,
    structured_hsv_target_attack,
)


def load_image(path, size):
    img = Image.open(path).convert("RGB").resize((size, size))
    img = torch.from_numpy(np.array(img)).permute(2, 0, 1).float() / 255.0
    return img.unsqueeze(0)


def main():
    parser = argparse.ArgumentParser(description="MAA single-pair demo")
    parser.add_argument("--img", type=str, required=True)
    parser.add_argument("--target_img", type=str, required=True)
    parser.add_argument("--img_size", type=int, default=224)
    parser.add_argument("--patch_size", type=int, default=16)
    parser.add_argument("--stride", type=int, default=2)
    parser.add_argument("--n_steps", type=int, default=15)
    parser.add_argument("--eps", type=float, default=8 / 255)
    parser.add_argument("--cheb_K", type=int, default=2)
    parser.add_argument("--learn_theta", type=int, default=1)
    parser.add_argument("--theta_lr", type=float, default=1e-2)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--device", type=str, default="cuda")
    parser.add_argument("--save", type=str, default=None, help="path to save the adversarial image")
    args = parser.parse_args()

    random.seed(args.seed)
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)
    torch.cuda.manual_seed_all(args.seed)
    device = torch.device(args.device if torch.cuda.is_available() else "cpu")

    src_img = load_image(args.img, args.img_size).to(device)
    tar_img = load_image(args.target_img, args.img_size).to(device)

    patch = args.patch_size
    stride = args.stride
    H = W = args.img_size
    nH = (H - patch) // stride + 1
    nW = (W - patch) // stride + 1
    adj = build_grid_adjacency(nH, nW, device=device)

    segmenter = MaskRCNNSegmenter(device)
    adv, perturbation, masks, q_map, theta = structured_hsv_target_attack(
        src_img, tar_img,
        adj=adj,
        segmenter=segmenter,
        block_hw=(patch, patch),
        stride=stride,
        steps=args.n_steps,
        eps=args.eps,
        cheb_K=args.cheb_K,
        learn_theta=bool(args.learn_theta),
        theta_lr=args.theta_lr,
    )

    print(f"L_inf: {perturbation.abs().max().item():.5f} (eps = {args.eps:.5f})")
    print(f"theta after per-instance optimization: {theta.numpy()}")

    if args.save:
        out = adv[0].detach().cpu().permute(1, 2, 0).clamp(0, 1).numpy()
        Image.fromarray((out * 255).astype(np.uint8)).save(args.save)
        print(f"adversarial image saved to {args.save}")


if __name__ == "__main__":
    main()
