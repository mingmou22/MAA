"""Channel-wise feature operators: fractal (H), style Gram (S)."""

import torch
import torch.nn as nn
import torch.nn.functional as F
import torchvision.models as models


class FractalHOperator(nn.Module):
    def forward(self, H):
        return F.avg_pool2d(H.unsqueeze(1), 3, 1, 1).squeeze(1)


class VGGStyle(nn.Module):
    def __init__(self):
        super().__init__()
        try:
            weights = models.VGG19_Weights.DEFAULT
            vgg = models.vgg19(weights=weights).features
        except Exception:
            vgg = models.vgg19(pretrained=True).features

        self.layers = nn.Sequential(*list(vgg)[:16])
        for p in self.parameters():
            p.requires_grad = False

    @staticmethod
    def gram(x):
        B, C, H, W = x.shape
        f = x.view(B, C, H * W)
        return torch.bmm(f, f.transpose(1, 2)) / (C * H * W + 1e-8)

    def forward(self, x):
        return self.layers(x)
