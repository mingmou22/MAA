"""MAA: Meta-Adversarial Attacks via channel-wise structure-guided perturbations."""

from .attack import structured_hsv_target_attack
from .diffusion import ChebDiffusion
from .graph import build_grid_adjacency, centrality_weights
from .segmentation import MaskRCNNSegmenter

__version__ = "1.0.0"
__all__ = [
    "structured_hsv_target_attack",
    "ChebDiffusion",
    "build_grid_adjacency",
    "centrality_weights",
    "MaskRCNNSegmenter",
]
